namespace BlogManagementAPI.Tests;
using BlogManagementAPI.Controllers;
using BlogManagementAPI.Models;
using BlogManagementAPI.DbContext;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

public class BlogPostsControllerTests
{
    private readonly BlogPostsController _controller;
    private readonly ApplicationDbContext _context;

    public BlogPostsControllerTests()
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Use a unique name
            .Options;

        _context = new ApplicationDbContext(options);
        _controller = new BlogPostsController(_context);
    }

    [Fact]
    public async Task GetBlogPosts_ReturnsAllBlogPosts()
    {
        // Arrange
        _context.BlogPosts.Add(new BlogPost { Id = 1, Username = "User1", DateCreated = DateTime.Now, Text = "Test Post" });
        _context.BlogPosts.Add(new BlogPost { Id = 2, Username = "User2", DateCreated = DateTime.Now, Text = "Another Post" });
        await _context.SaveChangesAsync();

        // Act
        var result = await _controller.GetBlogPosts();

        // Assert
        var actionResult = Assert.IsType<ActionResult<IEnumerable<BlogPost>>>(result);
        var okResult = Assert.IsType<List<BlogPost>>(actionResult.Value);
        Assert.Equal(2, okResult.Count);
    }

    [Fact]
    public async Task CreateBlogPost_ReturnsCreatedPost()
    {
        // Arrange
        var newPost = new BlogPost
        {
            Username = "User1",
            DateCreated = DateTime.Now,
            Text = "New Post"
        };

        // Act
        var result = await _controller.CreateBlogPost(newPost);

        // Assert
        var actionResult = Assert.IsType<ActionResult<BlogPost>>(result);
        var createdResult = Assert.IsType<CreatedAtActionResult>(actionResult.Result);
        var createdPost = Assert.IsType<BlogPost>(createdResult.Value);
        Assert.Equal("New Post", createdPost.Text);
        Assert.Equal("User1", createdPost.Username);
    }

    [Fact]
    public async Task UpdateBlogPost_ReturnsNoContent()
    {
        // Arrange
        var existingPost = new BlogPost
        {
            Id = 100,
            Username = "User1",
            DateCreated = DateTime.Now,
            Text = "Existing Post"
        };
        _context.BlogPosts.Add(existingPost);
        await _context.SaveChangesAsync();

        var updatedPost = new BlogPost
        {
            Id = 100,
            Username = "User1",
            DateCreated = DateTime.Now,
            Text = "Updated Post"
        };

        // Act
        var result = await _controller.UpdateBlogPost(1, updatedPost);

        // Assert
        Assert.IsType<NoContentResult>(result);
        var updatedEntity = await _context.BlogPosts.FindAsync(1);
        Assert.Equal("Updated Post", updatedEntity.Text);
    }

    [Fact]
    public async Task DeleteBlogPost_ReturnsNoContent()
    {
        // Arrange
        var postToDelete = new BlogPost
        {
            Id = 100,
            Username = "User1",
            DateCreated = DateTime.Now,
            Text = "Post to Delete"
        };
        _context.BlogPosts.Add(postToDelete);
        await _context.SaveChangesAsync();

        // Act
        var result = await _controller.DeleteBlogPost(1);

        // Assert
        Assert.IsType<NoContentResult>(result);
        Assert.Null(await _context.BlogPosts.FindAsync(1));
    }
}
